DP_KEY 10 — Diagnostics pack (what each file is)

- 10__base_by_root.csv: core table per ICD_ROOT × PROC with counts, n, mode, confidence, HAL_0.90, feasible levels.
- 10__completeness_map.csv: coverage view: n_total, n_valid, pct_valid.
- 10__dupes_exact.csv: exact duplicate rows.
- 10__dupes_near_desc.csv: descriptions differing only by casing/punctuation.
- 10__feasible_audit_by_proc.csv: LOS values that actually occur per PROC.
- 10__drift_monthly.csv: monthly valid rate and LOS shares (if dates exist).
- 10__mode_conf_heatmap_table.csv: pivotable table for a heatmap.
- 10__tie_entropy_by_root.csv: tie flag, entropy, gini per group.
- 10__hal_vs_mode_delta.csv: (HAL - mode) step-up indicators.
- 10__topN_volume_by_proc.csv: top 50 ICD roots by n per PROC.
- 10__top_uncertainty_hotspots.csv: high volume + low confidence.
- 10__coverage_funnel.csv: total → valid → green → review.
- 10__sibling_proc_compare.csv: cross-family consistency by ICD_ROOT.
- 10__dpkey_consistency.csv: DP_KEY (e.g., 9 vs 10) consistency.
- 10__sensitivity_sweep.csv: coverage as MIN_N/TAU change.
- per_proc/<proc>__one_pager.csv: simple per-PROC artifact for stakeholders.
